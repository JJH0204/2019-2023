﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monster : MonoBehaviour
{
    public void MonsterMove(Vector3 vDir)
    {
        this.gameObject.transform.position += vDir * Time.deltaTime;
    }
}
