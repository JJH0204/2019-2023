#include "State.h"

void main()
{
	Context cContext;
	cContext.GoNext();
	cContext.GoNext();
	cContext.GoNext();

	Context cContextA(new StateThree);
	cContextA.GoNext();
	cContextA.GoNext();
}