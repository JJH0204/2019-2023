﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{
    //Item kinds data
    public enum Item_Kinds {TEMP , SWORD, GUN, BULLET, POTION, BOX};
    public Item_Kinds Kinds;

    public bool isOnHands;             //아이템이 땅에 떨어진 경우 true, 아닌경우 false
    
    //Item Status
    public string m_sItemName;
    public int m_nHaveCount;
    public int m_nMaxHaveCount;

    public float m_fHp;
    public float m_fDef;
    public float m_fPower;
    public float m_fSpeed;
    public float m_fAtkSpeed;

    public float m_fAtkRadius;

    //Item(BULLET) Data
    public Vector3 startForc;

    //Item(Warpon) Data
    public GameObject m_gbullet;
    public GameObject ShootPos;

    //ItemFunction
    //public float GetAtkRadius()
    //{
    //    return m_fAtkRadius;
    //}

    //public void ItemToDrop()
    //{
    //    if(isOnHands != true)
    //    {
    //        this.gameObject.GetComponent<BoxCollider2D>().enabled = true;
    //        if(this.Kinds != Item_Kinds.BOX)
    //        {
    //            this.gameObject.GetComponent<BoxCollider2D>().isTrigger = true;
    //        }
    //        else
    //        {
    //            this.gameObject.GetComponent<BoxCollider2D>().isTrigger = false;
    //        }
    //    }
    //    else
    //    {
    //        this.gameObject.GetComponent<BoxCollider2D>().enabled = false;
    //    }
    //}
    //public void ItemGetDrop()
    //{
        
    //}

    //public void CollisionOnOff(string str)
    //{
    //    if (str == "On") isDrop = true;
    //    else isDrop = false;
    //}
    public void OnHands()
    {
        isOnHands = true;
        this.gameObject.GetComponent<BoxCollider2D>().enabled = false;
    }


    //collision(trigger)Enter function _ bullet, Box, POTION
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(this.Kinds == Item_Kinds.BULLET)
        {
            Rigidbody2D thisRigid = this.gameObject.GetComponent<Rigidbody2D>();
            thisRigid.AddForce(-startForc);
            if (collision.gameObject.tag == "Monster" || collision.gameObject.tag == "Player")
            {
                Character MonsterChar = collision.gameObject.GetComponent<Character>();
                MonsterChar.SetHP(MonsterChar.GetHP() - m_fPower / MonsterChar.GetShilde());
            }
            Destroy(this.gameObject);
        }
    }

    //If Itemkinds is warpon to running Function
    public void shoot(GameObject Target, float UserPower)
    {

        Vector3 vThisPos = ShootPos.transform.position;
        Vector3 vTargetPos = Target.transform.position;
        Vector3 vDist = vTargetPos - vThisPos;
        Vector3 vDirResult = vDist.normalized;
        GameObject ShootBullet = Instantiate(m_gbullet);
        ShootBullet.transform.position = ShootPos.transform.position;
        //Debug.Log("ShootBullet.Position : " + ShootBullet.transform.position);
        //Debug.Log("ShootPos : " + ShootPos.transform.position);
        Rigidbody2D RigidBullet = ShootBullet.GetComponent<Rigidbody2D>();


        RigidBullet.AddForce(ShootBullet.GetComponent<Item>().startForc = vDirResult * 300);
        ShootBullet.GetComponent<Item>().m_fPower = UserPower + this.m_fPower;
    }
    public void shoot(Vector3 Target, float UserPower)
    {

        GameObject ShootBullet = Instantiate(m_gbullet);
        ShootBullet.transform.position = ShootPos.transform.position;
        Rigidbody2D RigidBullet = ShootBullet.GetComponent<Rigidbody2D>();

        ShootBullet.GetComponent<Item>().startForc = Target * 300;
        ShootBullet.GetComponent<Item>().m_fPower = UserPower + this.m_fPower;
        RigidBullet.AddForce(Target * 300);
    }

    public void SwordAtk(GameObject Target, float UserPower)
    {
        Character MonsterChar = Target.gameObject.GetComponent<Character>();
        MonsterChar.SetHP(MonsterChar.GetHP() - (UserPower + m_fPower) / MonsterChar.GetShilde());
    }
    //private void Update()
    //{
    //    ItemToDrop();
    //}
}
/*상속한 아이템 클래스를 개선
 * warpon, bullet, Box 등을 아이템 클래스와 함쳐서 구현
 * bullet은 아이템으로 분류하지 않아도 될 것 같다.
 * bullet은 생성시 연결(?)된 무기의 공격력 값과 캐릭터의 공격력 값을 받아 충돌시 충돌된 해당 캐릭터에 PH를 감소시키는(데미지 처리) 작업을 실행한다.
 * 
 * Warpon과 박스는 아이템으로 분류하게 되면 어떻게 될까?
 * Item과 warpon은 구별해서 사용하자
 * Item은 
 */


//기획 변경 소비 아이템의 개수를 줄이고 획득 처는 던전 또는 시작 방에서, 게임을 플레이하며 가지게 된다.
//소비아이템의 개수는 체력회복, 방어막 회복, 공격력 버프, 이동속도 버프, 방어력 버프, 해독제, 피버 모드로 7개로 구성되며 던전에서 발견할 수 있다. (던전엔 파이터의 페어리와 비슷하게 플레이어 캐릭터가 해당 구슬의 가까이로 이동해야 해당 구슬에 해당하는 효과를 받을 수 있다. 또는 던전 클리어시 자동으로 버프가 적용되기도 한다.
//해독제, 피버 모드는 특수하게 사용버튼을 따로 두어 던전에서 획득한 해당 아이템을 사용시 버프를 적용 받을 수 있게 된다. (소비 타이밍을 유저가 컨트롤 할 수 있음)
//인벤토리에 해당 소비 아이템은 따로 표시하지 않고 오로지 인벤토리에는 무기 아이템만 표시된다.
//소지하지 않은 소비 아이템은 회색으로 칠해져 표시되고 사용시 쿨타임은 소비 아이템 버튼위에 표시 된다.


//public Item() { }
//public Item(string _name, int _havecount, int _maxhave, float _hp, float _def, float _power, float _speed, float _atkspeed, float _atkradius)
//{
//    m_sItemName = _name ;
//    m_nHaveCount = _havecount;
//    m_nMaxHaveCount= _maxhave;

//    m_fHp=_hp;
//    m_fDef = _def;
//    m_fPower = _power;
//    m_fSpeed = _speed;
//    m_fAtkSpeed = _atkspeed;

//    m_fAtkRadius = _atkradius;
//}
//public Item(float _hp, float _def, float _power, float _speed, float _atkspeed){ }

//박스의 체력이 0이 되면 파괴되고 지정된 아이템이 기존의 박스 자리에 출력되도록 함

//1. 총알을 생성한다.
//2. 총알을 캐릭터 시선 방향으로 힘을 줘 이동하게 한다.
//3. 일정 거리 이상 이동 했을 때 or 일정 시간동안 이동하면 총알을 삭제
//4. 총알이 벽에 부딫히면 삭제
//5. 총알이 몬스터에 부딫히면 대상에게 데미지 부여


////중간 정리 
//원거리 무기의 경우 (총, 활) 공격 범위가 없다. 대신 캐릭터가 바라보는 방향으로 탄을 발사 할 수 있으며 발사한 해당 탄에 시간 값을 주어 탄의 유지 시간을 설정한다.
//근거리 무기의 경우 (검) 공격 범위가 있다. 해당 공격 범위값을 캐릭터를 통해 확인하고 해당 범위에 몬스터가 있을 때 공격을 성공할 수 있도록 해야 한다.
