﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character : MonoBehaviour
{
    public float fHP;                   //체력
    public float fShilde;               //방어력
    public float fPower;                //공격력
    public float fSpeed;                //이동속도
    public float fSeeRadius;            //시야범위 ( 몬스터마다 다를 예정, 플레이어는 항상 기본 상태 )

    public float Max_fHP;               //상태 최대 값
    public float Max_fShilde;               
    public float Max_fPower;                
    public float Max_fSpeed;                
    public float Max_fSeeRadius;
    
    public Item m_UseItem;
    public Item m_SubItem;
    public GameObject m_drowpos;
    public GameObject m_drowItem;

    public Vector3 vStandDir;

    public Character() { }
    public Character(float _hp, float _Shilde, float _power, float _speed, float _Seeradius)
    {
        fHP = _hp;
        fShilde = _Shilde;
        fPower = _power;
        fSpeed = _speed;
        fSeeRadius = _Seeradius;
    }

    public float GetHP()
    {
        return fHP;
    }
    public float GetMaxHP()
    {
        return Max_fHP;
    }
    public float GetShilde()
    {
        return fShilde;
    }
    public float GetPower()
    {
        return fPower;
    }
    public float GetSpeed()
    {
        return fSpeed;
    }
    public float GetSeeRadius()
    {
        return fSeeRadius;
    }
    
    public void SetHP(float _hp)
    {
        fHP = _hp;
    }
    public void SetShilde(float _shilde)
    {
        fShilde = _shilde;
    }
    public void SetPower(float _power)
    {
        fPower = _power;
    }
    public void SetSpeed(float _speed)
    {
        fSpeed = _speed;
    }
    public void SetSeeRadius(float _seeradius)
    {
        fSeeRadius = _seeradius;
    }

    //####test Data
    
    //####test Function
    

    public void Move(Vector3 vDir)
    {
        this.gameObject.transform.position += vDir * Time.deltaTime * fSpeed;
        vStandDir = vDir;
    }

    //basic_func
    public void Death()
    {
        Destroy(m_drowItem);
        Destroy(this.gameObject);
    }

    void DrowItme()
    {
        if ((m_UseItem != null) && (m_drowItem == null))
            m_drowItem = Instantiate(m_UseItem.gameObject);

        m_drowItem.transform.position = m_drowpos.transform.position;
        m_drowItem.GetComponent<Item>().OnHands();
    }

    public void Attack(GameObject Seetarget, GameObject AtkTarget)
    {
        if (m_drowItem == null)
            return;
        if (m_drowItem.GetComponent<Item>().Kinds == Item.Item_Kinds.GUN)
        {
            if (Seetarget == null)
                m_drowItem.GetComponent<Item>().shoot(vStandDir, fPower);
            else
                m_drowItem.GetComponent<Item>().shoot(Seetarget, fPower);
        }
        else if (m_drowItem.GetComponent<Item>().Kinds == Item.Item_Kinds.SWORD)
        {
            //공격 모션 출력
            if (AtkTarget == null)
            {
                //무기의 공격 범위에 몬스터가 없을 경우 몬스터에게 데미지를 줄수 없다.

            }
            else
            {
                m_drowItem.GetComponent<Item>().SwordAtk(AtkTarget, fPower);
                //공격 범위에 몬스터가 있을 경우 몬스터에게 데미지를 줄 수 있다.
            }
        }
    }


    public void SeeTrak(GameObject Target)
    {
        if(Target != null)
        {
            Vector3 thisChar = this.transform.position;
            Vector3 TargetChar = Target.transform.position;
            Vector3 vDist = TargetChar - thisChar;
            if (vDist.x > 0)
            {
                transform.localRotation = Quaternion.Euler(0, 180, 0);
                m_drowItem.transform.localRotation = Quaternion.Euler(0, 180, 0);
            }
            else
            {
                transform.localRotation = Quaternion.Euler(0, 0, 0);
                m_drowItem.transform.localRotation = Quaternion.Euler(0, 0, 0);
            }
        }
        else
        {
            if(vStandDir == Vector3.right)
            {
                transform.localRotation = Quaternion.Euler(0, 180, 0);
                m_drowItem.transform.localRotation = Quaternion.Euler(0, 180, 0);
            }
            else if (vStandDir == Vector3.left)
            {
                transform.localRotation = Quaternion.Euler(0, 0, 0);
                m_drowItem.transform.localRotation = Quaternion.Euler(0, 0, 0);
            }

        }
    }

    private void Start()
    {
        //m_drowItem = null;
        //ThisSprite = this.gameObject.GetComponent<SpriteRenderer>();
    }

    private void Update()
    {
        DrowItme();
        
            
    }

    //Player_func
    

    


    //Monster_func
    

    
   
}
/* 수정 예정 사항 
 * 1. 몬스터와 Player 캐릭터의 클래스 컴포넌트를 분리해 사용해볼까? (아직 필요는 없는 것 같다.)
 * 2. 캐릭터의 공격 딜레이 타임은 무기에 있는 데이터를 참조해 사용해야 한다. (캐릭터 클레스에 해당 데이터가 필요 없다는 의미)
 * 3. 캐릭터의 체력에 비래하게 출력되는 이미지의 색을 투명하게 표시한다.(완료
 * 체력이 40%이하로 내려갈시 캐릭터 색을 빨강으로 변경(완료
 * 
 * */