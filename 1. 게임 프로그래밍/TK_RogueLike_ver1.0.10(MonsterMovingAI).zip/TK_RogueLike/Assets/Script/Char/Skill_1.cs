﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Skill_1 : MonoBehaviour
{
    //SkillName : Throw knife's
    //public GameObject[] KnifePos;       //이 생성될 위치 
    //public GameObject KnifePrefap;      //생성할 칼 프리팹
    //public GameObject[] ProdKnife;      //생성된 칼 게임오브젝트
    //public bool isSkillOn;              //스킬 사용여부 확인

    //public float fThrowSpeed;

    //public void SkillOn()
    //{
    //    if(isSkillOn == false)
    //    {
    //        isSkillOn = true;
    //        ProdKnife = new GameObject[KnifePos.Length];
    //        for(int count = 0; count < ProdKnife.Length; count++)
    //        {
    //            ProdKnife[count] = Instantiate(KnifePrefap);
    //            ProdKnife[count].transform.position = KnifePos[count].transform.position;
    //        }
    //    }
    //}

    //public void ThrowKnife_s(GameObject TargetPlayer)
    //{
    //    if(isSkillOn == true)
    //    {
    //        Vector3 vDist = TargetPlayer.transform.position - 
    //    }
    //}

    //public void Trow()
    //{

    //}
    public GameObject KnifePos;
    public GameObject KnifePrefap;
    public GameObject ProdKnife;

    public bool isSkill;
    private void Awake()
    {
        isSkill = false;
    }

    public IEnumerator UseSkill(GameObject Target)
    {
        isSkill = true;
        //SponKnife();
        yield return new WaitForSeconds(0.5f);
        //ThrowKnife();
        isSkill = false;
    }

    public void SponKnife()
    {

    }
}
