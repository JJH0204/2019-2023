﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/* 몬스터 이동 행동 구현
 * 1. 시야 범위내 적(Player)가 없으면 추적하지 않고 움직인다.
 * 2. 시야 범위내 적을 발견하면 적을 추적해 움직인다.
 * 3. 시야 범위내 적을 추적해 공격가능 범위에 들어오면 움직이지 않고 공격한다.
 * 예외사항) 적으로 부터 공격 받았을 때 해당 적을 타겟으로 행동한다.
 * */
public class MonAI : MonoBehaviour
{
    Character ThisMon;
    SpriteRenderer ThisSprite;

    public enum CharState { IDLE, MOVE, ATTACK , DEATH };
    public CharState ThisCharState;

    public enum MoveDir { IDLE, TOP, RIGHT, BOTTOM, LEFT, TR, BR, BL, TL };
    public MoveDir ThisMoveDir;

    public GameObject m_gSeeTarget;
    public GameObject m_gAtkTarget;
    
    public Vector3 vResultDir;

    public float deleyAtk;              //공격 대기 시간 () 아이템의 공격대기시간도 추가로 계산

    public bool isAttack;
    public bool isSetDir;

    private void Awake()
    {
        ThisMon = this.GetComponent<Character>();
        ThisSprite = this.gameObject.GetComponent<SpriteRenderer>();
        isAttack = false;
        isSetDir = false;
    }

    void Start()
    {

    }

    void Update()
    {
        SpriteColorChange();
        
        Action();
        //if (m_gAtkTarget == null)
        //    MonMove();
        //else if (m_gAtkTarget != null)
        //    if (ThisCharState == CharState.ATTACK)
        //        StartCoroutine(MonAtk());
    }

    private void FixedUpdate()
    {
        Mon_AI();
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(this.transform.position, ThisMon.GetSeeRadius());
        if (ThisMon.m_drowItem != null)
            if (ThisMon.m_drowItem.GetComponent<Item>().m_fAtkRadius > 0)
                Gizmos.DrawWireSphere(this.transform.position, ThisMon.m_drowItem.GetComponent<Item>().m_fAtkRadius);
    }

    private void Action()
    {
        ThisMon.SeeTrak(m_gSeeTarget);

        switch (ThisCharState)
        {
            case CharState.IDLE:  //기본 상태
                
                //행동 여부 판단
                //이동 방향 선정
                //이동 상태로 변경
                break;
            case CharState.MOVE:  //이동 상태

                //선정한 이동 방향으로 이동
                //행동 여부 판단
                //만약 이동 상태 유지할 경우
                //이동 방향 선정
                ThisMon.Move(vResultDir);
                Debug.Log(vResultDir);
                //지정된 대상을 향해 이동
                //지정된 대상이 유지 된다면 
                break;
            case CharState.ATTACK://공격 상태
                if(isAttack == false)
                {
                    StartCoroutine(MonAtk());
                }
                
                //지정된 대상 공격
                break;
            case CharState.DEATH:   //죽음 상태
                ThisMon.Death();
                break;
        }

        //Invoke("MonsterAI", 5);
    }
    public void SpriteColorChange()
    {
        float result = (ThisMon.GetHP() / ThisMon.GetMaxHP()) * 100.0f;

        if (result < 40.0f)
            ThisSprite.color = new Color(255, 0, 0, 255);
    }

    private void Move() { this.gameObject.transform.position += vResultDir * Time.deltaTime * ThisMon.GetSpeed();
        Debug.Log(vResultDir);

    }

    IEnumerator MonAtk()
    {
        isAttack = true;
        ThisMon.Attack(m_gSeeTarget, m_gAtkTarget);
        yield return new WaitForSeconds(deleyAtk);
        isAttack = false;
    }

    void MonSeeTargetFinding(int nLayer)
    {
        Collider2D Seecollider = Physics2D.OverlapCircle(this.transform.position, ThisMon.GetSeeRadius(), nLayer);
        if (Seecollider != null)
        {
            m_gSeeTarget = Seecollider.gameObject;
        }
        else
        {
            if (m_gSeeTarget)
                if (m_gSeeTarget.tag == "Player")
                    m_gSeeTarget = null;
        }

        if (m_gSeeTarget)
        {
            Vector3 vTargetPos = m_gSeeTarget.gameObject.transform.position;
            Vector3 vPlayerPos = this.transform.position;

            Vector3 vDist = vTargetPos - vPlayerPos;
            Vector3 vDir = vDist.normalized;
            vResultDir = vDir;
        }
    }
    void MonAtkTargetFinding(int nLayer)
    {
        if (ThisMon.m_drowItem == null) return;
        Collider2D Atkcollider = Physics2D.OverlapCircle(this.transform.position, ThisMon.m_drowItem.GetComponent<Item>().m_fAtkRadius, nLayer);

        if (Atkcollider != null)
            m_gAtkTarget = Atkcollider.gameObject;
        else
        {
            if (m_gAtkTarget)
            {
                if (m_gAtkTarget.tag == "Player")
                    m_gAtkTarget = null;
            }
        }
    }
    private void Mon_AI()
    {
        int nLayer = 1 << LayerMask.NameToLayer("Player");
        MonSeeTargetFinding(nLayer);
        MonAtkTargetFinding(nLayer);

        if (ThisMon.GetHP() <= 0)
        {
            ThisCharState = CharState.DEATH;
        }
        else
        {
            if (m_gAtkTarget != null)
            {
                ThisCharState = CharState.ATTACK;
            }
            else if (m_gSeeTarget != null)
            {
                ThisCharState = CharState.MOVE;
            }
            else
            {
                // 이 부분을 코루틴으로 함수화 시키자
                if(isSetDir == false)
                    StartCoroutine(SetRandDir());
                //##############################
            }
        }
    }

    private IEnumerator SetRandDir()
    {
        //Debug.Log("Coroutine_1");
        //
        //Debug.Log("Coroutine_2");
        isSetDir = true;
        int nRand = Random.Range(0, 9);
        if (nRand > 0) ThisCharState = CharState.MOVE;
        else ThisCharState = CharState.IDLE;
        ThisMoveDir = (MoveDir)nRand;
        SetResultDir();
        yield return new WaitForSeconds(5.0f);
        isSetDir = false;
        //StopAllCoroutines();
        //Debug.Log("Coroutine_3");
        //yield return new WaitForSeconds(5.0f);
    }

    private void SetResultDir()
    {
        switch (ThisMoveDir)
        {
            case MoveDir.TOP:
                vResultDir = Vector3.up;
                break;
            case MoveDir.BOTTOM:
                vResultDir = Vector3.down;
                break;
            case MoveDir.LEFT:
                vResultDir = Vector3.left;
                break;
            case MoveDir.RIGHT:
                vResultDir = Vector3.right;
                break;
            case MoveDir.TL:
                vResultDir = Vector3.up + Vector3.left;
                break;
            case MoveDir.TR:
                vResultDir = Vector3.up + Vector3.right;
                break;
            case MoveDir.BL:
                vResultDir = Vector3.down + Vector3.left;
                break;
            case MoveDir.BR:
                vResultDir = Vector3.down + Vector3.right;
                break;
        }
        Debug.Log(vResultDir);
    }
    //동작과 ai를 분리 
    //ray 로 이동시 충돌된 지점과 반대되는 방향으로 몬스터가 이동할 수 있도록 감지 범위 설정하고 함수 재작
}
