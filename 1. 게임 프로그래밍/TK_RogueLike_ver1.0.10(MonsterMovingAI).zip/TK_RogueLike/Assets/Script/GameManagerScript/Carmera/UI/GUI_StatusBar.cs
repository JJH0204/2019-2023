﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using UnityEngine.UI;

public class GUI_StatusBar : MonoBehaviour
{
    public RectTransform StatusBar;
    public Vector2 vMaxSize;

    public void SetStatusBar(float cur, float max)
    {
        float fRat = cur / max;
        Vector2 vSize = StatusBar.sizeDelta;
        vSize.x = vMaxSize.x * fRat;
        StatusBar.sizeDelta = vSize;
    }
    // Start is called before the first frame update
    void Start()
    {
        vMaxSize = StatusBar.sizeDelta;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
