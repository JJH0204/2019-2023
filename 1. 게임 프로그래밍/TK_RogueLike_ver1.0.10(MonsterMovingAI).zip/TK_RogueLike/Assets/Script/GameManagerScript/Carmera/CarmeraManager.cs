﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarmeraManager : MonoBehaviour
{
    public GameObject Carmera;
    public PlayerManager PlayerManager;

    private void CarmeraTraking()
    {
        if (PlayerManager.Player == null) return;

        if(PlayerManager.Alive == true)
        {
            Vector3 vPos = Carmera.transform.position;
            Vector3 vTargetPos = PlayerManager.Player.transform.position;

            vTargetPos.z = vPos.z;

            Vector3 vDist = vTargetPos - vPos;
            Vector3 vDir = vDist.normalized;
            float fDist = vDist.magnitude;
            if (fDist > Time.deltaTime * (PlayerManager.Player.GetComponent<Character>().GetSpeed() / 1.5f))
                Carmera.transform.position += vDir * Time.deltaTime * (PlayerManager.Player.GetComponent<Character>().GetSpeed() / 1.5f);
        }
    }

    // Update is called once per frame
    void Update()
    {
        CarmeraTraking();
    }
}
