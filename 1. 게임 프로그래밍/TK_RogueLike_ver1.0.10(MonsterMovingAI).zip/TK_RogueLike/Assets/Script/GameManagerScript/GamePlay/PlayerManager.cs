﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerManager : MonoBehaviour
{
    public GameObject PlayerPrefap; //플레이어 캐릭터의 데이터
    public GameObject Player;   //게임내 출력되는 캐릭터

    public bool Alive;          //플레이어 캐릭터의 생존 여부

    
    public Vector3 DethPos;     //플레이어 캐릭터가 사망한 지점//리스폰시 생성될 위치
    public Vector3 BufPos;      //플레이어 캐릭터가 사망하게 되면 잠시 카메라에서 사라지게 만듬

    public bool IsSuperMode;    //플레이어 캐릭터가 현재 슈퍼모드인지 결정
    public float SuperTime;     //캐릭터의 슈퍼 모드 유지 시간(초)

    //Test Data
    private GameObject m_gSeeTarget;
    private GameObject m_gAtkTarget;
    //public GameObject TestSponPos;  //Room Manager에 들어가 데이터 (해결 1 순위)
    public float TestDeley;         //삭제예정 데이터(캐릭터 리스폰 (코루틴함수) 활용을 위한 데이터) (해결 2순위)

    private void OnDrawGizmos()
    {
        if (Player == null) return;
        Gizmos.DrawWireSphere(Player.transform.position, Player.GetComponent<Character>().GetSeeRadius());
        if (Player.GetComponent<Character>().m_drowItem != null)
            if (Player.GetComponent<Character>().m_drowItem.GetComponent<Item>().m_fAtkRadius > 0)
                Gizmos.DrawWireSphere(this.transform.position, Player.GetComponent<Character>().m_drowItem.GetComponent<Item>().m_fAtkRadius);
    }


    public void PlayerSpon(Vector3 SponPos) //플레이어 캐릭터 초기 생성
    {
        if(Alive == false)
        {
            if(Player == null)
            {
                Player = Instantiate(PlayerPrefap);
                Player.transform.position = SponPos;
                Alive = true;
            }
        }
    }

    public void PlayerRespon()  //플레이어 캐릭터 리스폰
    {
        if(Alive == false)
        {
            if(Player != null)
            {
                Alive = true;
                Player.GetComponent<Character>().fHP = 100;
                Player.transform.position = DethPos;
                IsSuperMode = true;
            }
        }
    }

    public void PlayerDeth()    //플레이어 사망 처리
    {
        if (Player == null) return;

        if(Player.GetComponent<Character>().fHP <= 0)
        {
            if (Alive == true)
            {
                Alive = false;
                DethPos = Player.transform.position;
                Player.transform.position = BufPos;
                
            }
        }
    }

    public void EndPlayer()     //게임 종료시 삭제
    {
        Player.GetComponent<Character>().Death();
        Player = null;
    }

    public void SuperMode()     //무적(슈퍼)모드
    {
        if (Player == null) return;
        if (IsSuperMode)
        {
            Player.GetComponent<Character>().fHP = Player.GetComponent<Character>().Max_fHP;
            StartCoroutine(coroutineSuperMode());
        }
    }

    IEnumerator coroutineSuperMode()
    {
        IsSuperMode = true;
        yield return new WaitForSeconds(SuperTime);
        IsSuperMode = false;
    }

    //TestFunction#################################
    IEnumerator TestPlayerSpon()
    {
        if(Alive == false)
        {
            yield return new WaitForSeconds(TestDeley);
            PlayerRespon();
            IsSuperMode = true;
        }
        Alive = true;
    }

    private void GetKey()
    {
        if (Input.GetKey(KeyCode.W))
            Player.GetComponent<Character>().Move(Vector3.up);
        if (Input.GetKey(KeyCode.A))
            Player.GetComponent<Character>().Move(Vector3.left);
        if (Input.GetKey(KeyCode.D))
            Player.GetComponent<Character>().Move(Vector3.right);
        if (Input.GetKey(KeyCode.S))
            Player.GetComponent<Character>().Move(Vector3.down);
        if (Input.GetKeyDown(KeyCode.K))
            Player.GetComponent<Character>().Attack(m_gSeeTarget, m_gAtkTarget);
        if (Input.GetKeyDown(KeyCode.L)) //아이템 변경
            ChangeItem();
    }
    private void ChangeItem()
    {
        Destroy(Player.GetComponent<Character>().m_drowItem);
        Item tempwarpon;
        if (Player.GetComponent<Character>().m_UseItem == null) tempwarpon = null;
        else tempwarpon = Player.GetComponent<Character>().m_UseItem;

        if (Player.GetComponent<Character>().m_SubItem == null) Player.GetComponent<Character>().m_UseItem = null;
        else Player.GetComponent<Character>().m_UseItem = Player.GetComponent<Character>().m_SubItem;

        if (tempwarpon == null) Player.GetComponent<Character>().m_SubItem = null;
        else Player.GetComponent<Character>().m_SubItem = tempwarpon;
    }


    void SeetargetFinding(int nLayer)
    {
        if (Player == null) return;
        Collider2D[] Seecollider = Physics2D.OverlapCircleAll(Player.transform.position, Player.GetComponent<Character>().GetSeeRadius(), nLayer);

        if (Seecollider.Length > 0)
        {
            int TargetNon = 0;
            Vector3 vLeastDist = Vector3.zero;
            for (int Seecount = TargetNon; Seecount < Seecollider.Length; Seecount++)
            {
                GameObject TempSee = Seecollider[Seecount].gameObject;
                if (TempSee.tag == "Monster")
                {
                    Vector3 vTargetPos = TempSee.gameObject.transform.position;
                    Vector3 vPlayerPos = this.transform.position;

                    Vector3 vDist = vTargetPos - vPlayerPos;
                    if (vLeastDist == Vector3.zero)
                    {
                        vLeastDist = vDist;
                        TargetNon = Seecount;
                    }
                    else if (vLeastDist.magnitude > vDist.magnitude)
                    {
                        vLeastDist = vDist;
                        TargetNon = Seecount;
                    }
                }
            }

            m_gSeeTarget = Seecollider[TargetNon].gameObject;
        }
        else
        {
            if (m_gSeeTarget)
            {
                if (m_gSeeTarget.tag == "Monster")
                    m_gSeeTarget = null;
            }
        }
    }

    //player캐릭터가 사용중인 무기의 공격 범위를 통해 공격 가능한 몬스터 확인
    void AtktargetFinding(int nLayer)
    {
        if (Player == null) return;
        if (Player.GetComponent<Character>().m_drowItem == null) return;
        Collider2D[] Atkcollider = Physics2D.OverlapCircleAll(Player.transform.position, Player.GetComponent<Character>().m_drowItem.GetComponent<Item>().m_fAtkRadius, nLayer);

        if (Atkcollider.Length > 0)
        {
            int TargetNon = 0;
            Vector3 vLeastDist = Vector3.zero;
            for (int Atkcount = TargetNon; Atkcount < Atkcollider.Length; Atkcount++)
            {
                GameObject TempAtk = Atkcollider[Atkcount].gameObject;
                if (TempAtk.tag == "Monster")
                {
                    Vector3 vTargetPos = TempAtk.gameObject.transform.position;
                    Vector3 vPlayerPos = this.transform.position;

                    Vector3 vDist = vTargetPos - vPlayerPos;
                    if (vLeastDist == Vector3.zero)
                    {
                        vLeastDist = vDist;
                        TargetNon = Atkcount;
                    }
                    else if (vLeastDist.magnitude > vDist.magnitude)
                    {
                        vLeastDist = vDist;
                        TargetNon = Atkcount;
                    }
                }
            }
            m_gAtkTarget = Atkcollider[TargetNon].gameObject;
        }
        else
        {
            if (m_gAtkTarget)
            {
                if (m_gAtkTarget.tag == "Monster")
                    m_gAtkTarget = null;
            }
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    private void FixedUpdate()
    {
        int nLayer = 1 << LayerMask.NameToLayer("Monster");
        SeetargetFinding(nLayer);
        AtktargetFinding(nLayer);
    }

    void Update()
    {
        if (Player == null) PlayerSpon(PlayManager.GetInstance().GetStartPos());
        StartCoroutine(TestPlayerSpon());
        SuperMode();
        PlayerDeth();
        GetKey();
        Player.GetComponent<Character>().SeeTrak(m_gSeeTarget);
    }

    private void LateUpdate()
    {
        if (PlayManager.GetInstance() == null) return;
        RoomManager NowRoom = PlayManager.GetInstance().DungeonManager.NowFloor.NowRoom;
        if (NowRoom.isClear)
        {
            if((NowRoom.EnterPotal().x != 0.0f) && (NowRoom.EnterPotal().y != 0.0f))
            {
                Player.transform.position = NowRoom.EnterPotal();
            }
        }
    }

}
/* 플레이어가 리스폰 된 이후 데미지를 받아 사망하게 되면 리스폰 대기 시간을 무시하고 다시 살아난다.
 * 
 * 코루틴을 제거하고 UI로 부활 버튼을 만들어 유저가 부활을 원할 때 부활을 할 수 있도록 만들어 보자
 */