﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Potal : MonoBehaviour
{
    public enum Potal_State { POTAL_OFF, POTAL_ON, POTAL_PAUSE};
    public Potal_State potal_state;
    // Start is called before the first frame update
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(potal_state == Potal_State.POTAL_OFF)
            potal_state = Potal_State.POTAL_ON;
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        potal_state = Potal_State.POTAL_OFF;
    }

    private void Start()
    {
        potal_state = Potal_State.POTAL_OFF;
    }
}
