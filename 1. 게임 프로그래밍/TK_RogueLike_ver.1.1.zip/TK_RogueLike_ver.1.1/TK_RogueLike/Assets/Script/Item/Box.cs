﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Box : Item
{
    public Box() { }
    public Box(float _HP)
    {
        base.m_fHp = _HP;
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //박스의 체력이 0이 되면 파괴되고 지정된 아이템이 기존의 박스 자리에 출력되도록 함
    }
}
