﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character : MonoBehaviour
{
    public float fHP;
    public float fShilde;
    public float fPower;
    public float fSpeed;
    public float fSeeRadius;
    public float fAtkRadius;
    public GameObject m_gSeeTarget;

    public Character() { }
    public Character(float _hp, float _Shilde, float _power, float _speed, float _Seeradius, float _Aktradius)
    {
        fHP = _hp;
        fShilde = _Shilde;
        fPower = _power;
        fSpeed = _speed;
        fSeeRadius = _Seeradius;
        fAtkRadius = _Aktradius;
    }
    
    public float GetHP()
    {
        return fHP;
    }
    public float GetShilde()
    {
        return fShilde;
    }
    public float GetPower()
    {
        return fPower;
    }
    public float GetSpeed()
    {
        return fSpeed;
    }
    public float GetSeeRadius()
    {
        return fSeeRadius;
    }
    
    public void SetHP(float _hp)
    {
        fHP = _hp;
    }
    public void SetShilde(float _shilde)
    {
        fShilde = _shilde;
    }
    public void SetPower(float _power)
    {
        fPower = _power;
    }
    public void SetSpeed(float _speed)
    {
        fSpeed = _speed;
    }
    public void SetSeeRadius(float _seeradius)
    {
        fSeeRadius = _seeradius;
    }
    //Monster 사망처리
    protected void Death()
    {
        if (fHP <= 0)
        {
            Destroy(this.gameObject);
        }
    }
}
