﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monster : Character
{
    public Vector3 vDirResult;
    public float deleyAtk;
    public bool isAtk;
    public GameObject AtkTarget;
    //생성자
    public Monster() { }
    public Monster(float _hp, float _Shilde, float _power, float _speed, float _Seeradius, float _Atkradius)
    {
        base.fHP = _hp;
        base.fShilde = _Shilde;
        base.fPower = _power;
        base.fSpeed = _speed;
        base.fSeeRadius = _Seeradius;
        base.fAtkRadius = _Atkradius;
    }

    IEnumerator MonAtk()
    {
        isAtk = true;
        Debug.Log("AtkTarget : " + AtkTarget.name);
        Debug.Log("Befor Atk : " + AtkTarget.GetComponent<Player>().fHP);
        AtkTarget.GetComponent<Player>().SetHP(AtkTarget.GetComponent<Player>().GetHP() - (base.fPower - AtkTarget.GetComponent<Player>().GetShilde()));
        Debug.Log("After Atk : " + AtkTarget.GetComponent<Player>().GetHP());
        yield return new WaitForSeconds(deleyAtk);
        isAtk = false;
    }

    //Player 추적용 함수
    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(this.transform.position, base.fSeeRadius);
        Gizmos.DrawWireSphere(this.transform.position, base.fAtkRadius);
    }
    private void FixedUpdate()
    {
        int nLayer = 1 << LayerMask.NameToLayer("PlayGround");

        Collider2D Seecollider = Physics2D.OverlapCircle(this.transform.position, base.fSeeRadius, nLayer);
        Collider2D Atkcollider = Physics2D.OverlapCircle(this.transform.position, base.fAtkRadius, nLayer);

        if ((Seecollider != null)&&(Seecollider.gameObject.tag == "Player"))
        {
            base.m_gSeeTarget = Seecollider.gameObject;
            //Debug.Log("SeeTarget : " + base.m_gSeeTarget.name);
        }
        else
        {
            if (base.m_gSeeTarget)
            {
                if ((base.m_gSeeTarget.tag == "Player")||(base.m_gSeeTarget.tag == "Monster"))
                {
                    base.m_gSeeTarget = null;
                    //Debug.Log("SeeFixedUpdate: null");
                }
                //else
                   // Debug.Log("SeeTarget:" + base.m_gSeeTarget);
            }
            //Debug.Log("SeeTarget is null");
        }

        if (base.m_gSeeTarget)
        {
            Vector3 vTargetPos = base.m_gSeeTarget.gameObject.transform.position;
            Vector3 vPlayerPos = this.transform.position;

            Vector3 vDist = vTargetPos - vPlayerPos;
            Vector3 vDir = vDist.normalized;
            vDirResult = vDir;
        }
        else
            vDirResult = Vector3.zero;

        if (Atkcollider != null)
            AtkTarget = Atkcollider.gameObject;
        else
            if (AtkTarget)
                if ((AtkTarget.tag == "Player")||(AtkTarget.tag == "Monster"))
                    AtkTarget = null;
    }
    private void MonMove()
    {
        this.gameObject.transform.position += vDirResult * Time.deltaTime * base.fSpeed;
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        MonMove();
        if(AtkTarget != null)
        {
            if(isAtk == false)
                StartCoroutine(MonAtk());
        }
        
        base.Death();
    }
}
