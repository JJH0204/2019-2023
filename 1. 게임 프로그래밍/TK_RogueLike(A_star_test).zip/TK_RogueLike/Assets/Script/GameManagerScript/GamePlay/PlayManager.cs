﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayManager : MonoBehaviour
{
    static PlayManager instance;

    public ItemManager ItemManager;
    public DungeonManager DungeonManager;
    public PlayerManager PlayerManager;

    public static PlayManager GetInstance() { return instance; }

    


    public Vector3 GetStartPos() { return DungeonManager.NowFloor.NowRoom.PlayerSponPos.transform.position; }
    
    public GameObject GetPotalPrefap() { return DungeonManager.NowFloor.Potalprefap; }


    // Start is called before the first frame update
    void Start()
    {
        instance = this;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
