﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class RoomManager : MonoBehaviour
{
    //MonsterSponData##################################
    public List<GameObject> m_lCreatPos;
    public GameObject m_gCreatObj;
    public int m_nCreatCount;
    private GameObject[] m_lMonsters;           //다수의 몬스터 관리
    private GameObject m_Monster;               //하나의 몬스터 관리
    private List<int> RandIndex;
    private bool isMonSpon;
    //#################################################
    //RoomData#########################################
    public enum RoomKind { TEST, START, NORMAL, ELITE, BOSS, EVENT };  //방 종류 열거형
    public RoomKind Kind;                                              //방 종류 표시
    //public string ThisRoomKind;                                 //입력 받는 방 종류

    public bool isRand;                                         // 방이 그려졌는지 확인
    public bool isClear;                                        //플레이어가 방을 클리어 했는지 확인
    public bool isPotalSpon;                                    //포탈이 그려졌는지 유무판단
    //방에 연결된 다른 방의 정보
    public RoomManager Connect_UP;
    public RoomManager Connect_DOWN;
    public RoomManager Connect_LEFT;
    public RoomManager Connect_RIGHT;

    //Room Potal Data
    public GameObject UP_Potal;
    public GameObject DOWN_Potal;
    public GameObject LEFT_Potal;
    public GameObject RIGHT_Potal;

    public GameObject UP_PotalPos;
    public GameObject DOWN_PotalPos;
    public GameObject LEFT_PotalPos;
    public GameObject RIGHT_PotalPos;

    //PlayerSponPos
    public GameObject PlayerSponPos;
    //#################################################
    //MonsterSponFunction##############################
    private bool ListSearch(int Data)
    {
        if (RandIndex.Count != 0)
        {
            for (int count = 0; count < RandIndex.Count; count++)
            {
                if (RandIndex[count] == Data)
                    return false;
            }
        }
        return true;
    }   //랜덤생성 함수
    private int ChoiceRand()
    {
        while (true)
        {
            int nIndex = (int)Random.Range(0f, 4f);
            if (ListSearch(nIndex))
            {
                RandIndex.Add(nIndex);
                return nIndex;
            }
        }
    }           //랜덤생성 함수
    public void SponMonster()
    {
        if (isMonSpon == true || isClear == true) return;

        if (m_nCreatCount > 1)
        {
            m_lMonsters = new GameObject[m_nCreatCount];
            RandIndex = new List<int>();
            for (int count = 0; count < m_nCreatCount; count++)
            {
                m_lMonsters[count] = Instantiate(m_gCreatObj);
                m_lMonsters[count].transform.position = m_lCreatPos[ChoiceRand()].transform.position;
            }
        }
        else
        {
            m_Monster = Instantiate(m_gCreatObj);
            m_Monster.transform.position = m_lCreatPos[0].transform.position;
        }

        isMonSpon = true;
    }
    public bool StillAliveMon()
    {
        if (m_nCreatCount > 1)
        {
            for (int count = 0; count < m_nCreatCount; count++)
            {
                if (m_lMonsters[count] != null)
                    return false;
            }
        }
        else
        {
            if (m_Monster != null)
            {
                return false;
            }
        }

        return true;
    }
    //#################################################
    //RoomBaiscFunction################################
    private void SetRoomData()
    {
        isMonSpon = false;
        isPotalSpon = false;
        isRand = false;
        isClear = false;
    }
    private void RandPotal()
    {
        if (isClear)
        {
            if (isPotalSpon == true) return;

            if (Connect_UP != null)
            {
                UP_Potal = Instantiate(PlayManager.GetInstance().GetPotalPrefap());
                UP_Potal.transform.position = UP_PotalPos.transform.position;
            }
            if (Connect_DOWN != null)
            {
                DOWN_Potal = Instantiate(PlayManager.GetInstance().GetPotalPrefap());
                DOWN_Potal.transform.position = DOWN_PotalPos.transform.position;
            }
            if (Connect_LEFT != null)
            {
                LEFT_Potal = Instantiate(PlayManager.GetInstance().GetPotalPrefap());
                LEFT_Potal.transform.position = LEFT_PotalPos.transform.position;
            }
            if (Connect_RIGHT != null)
            {
                RIGHT_Potal = Instantiate(PlayManager.GetInstance().GetPotalPrefap());
                RIGHT_Potal.transform.position = RIGHT_PotalPos.transform.position;
            }
            isPotalSpon = !isPotalSpon;
        }
    }
    public Vector3 EnterPotal()
    {
        if (isClear == false) return Vector3.zero;
        //포털 이동이 원하는 위치로 작동하지 않는다.(에러)
        //1. 포탈의 이동 위치가 (0.0 , 0.0)으로 되어 있어 이동 금지 조건과 동일해 이동 되지 않았다. 새로운 조건식이 필요
        //2. FloorManager에서 NowRoom을 변경하지 않았다.
        if (UP_Potal != null && UP_Potal.GetComponent<Potal>().potal_state == Potal.Potal_State.POTAL_ON)
        {
            PlayManager.GetInstance().DungeonManager.NowFloor.NowRoom = Connect_UP;
            if (Connect_UP.isClear == true)
                Connect_UP.DOWN_Potal.GetComponent<Potal>().potal_state = Potal.Potal_State.POTAL_PAUSE;
            return Connect_UP.DOWN_PotalPos.transform.position;
        }
        else if (DOWN_Potal != null && DOWN_Potal.GetComponent<Potal>().potal_state == Potal.Potal_State.POTAL_ON)
        {
            PlayManager.GetInstance().DungeonManager.NowFloor.NowRoom = Connect_DOWN;
            if (Connect_DOWN.isClear == true)
                Connect_DOWN.UP_Potal.GetComponent<Potal>().potal_state = Potal.Potal_State.POTAL_PAUSE;
            return Connect_DOWN.UP_PotalPos.transform.position;
        }
        else if (RIGHT_Potal != null && RIGHT_Potal.GetComponent<Potal>().potal_state == Potal.Potal_State.POTAL_ON)
        {
            PlayManager.GetInstance().DungeonManager.NowFloor.NowRoom = Connect_RIGHT;
            if (Connect_RIGHT.isClear == true)
                Connect_RIGHT.LEFT_Potal.GetComponent<Potal>().potal_state = Potal.Potal_State.POTAL_PAUSE;
            return Connect_RIGHT.LEFT_PotalPos.transform.position;
        }
        else if (LEFT_Potal != null && LEFT_Potal.GetComponent<Potal>().potal_state == Potal.Potal_State.POTAL_ON)
        {
            PlayManager.GetInstance().DungeonManager.NowFloor.NowRoom = Connect_LEFT;
            if (Connect_LEFT.isClear == true)
                Connect_LEFT.RIGHT_Potal.GetComponent<Potal>().potal_state = Potal.Potal_State.POTAL_PAUSE;
            return Connect_LEFT.RIGHT_PotalPos.transform.position;
        }

        return Vector3.zero;
    }
    //#################################################
    // Start is called before the first frame update
    void Start()
    {
        SetRoomData();
        SponMonster();
    }

    // Update is called once per frame
    void Update()
    {

        isClear = StillAliveMon();
        RandPotal();
    }
    //방생성 알고리즘
    /* 1. 방의 형태를 데이터화 시켜 저장한다.
     * 2. 지정된 배열의 위치에 데이터를 참조해 구조물을 배치한다.
     * 3. 저장한 데이터와 배치한 구조물의 형태가 동일한지 검사한다.
     * 4. (3)의 결과가 참일 경우 게임을 실행한다.
     * */
    //testdata
    //enum BlockState { FLOOR = 1, WALL, MONSPON, POTAL }
    //public int[,] RoomData;
    //public const int RoomWidth = 6;
    //public const int RoomHigh = 6;
    public int RoomHight, RoomWidth;

    //testFunc
    //void TestAwake()
    //{
    //    //파일 읽어 오기(저장)
    //    RoomData = new int[RoomHigh, RoomWidth] { { 2, 2, 2, 2, 2, 2 }, { 2, 1, 1, 1, 1, 2}, { 2, 1, 1, 1, 1, 2 }, { 2, 1, 1, 1, 1, 2 }, { 2, 1, 1, 1, 1, 2 }, { 2, 2, 2, 2, 2, 2 } };
    //    //생성할 타일의 이미지를 받아옴
    //    //저장한 데이터 활용해 타일 생성하기
    //    RandRoom();
    //}
    //void RandRoom()
    //{
        
    //    for(int HighCount = 0; HighCount < RoomData.GetLength(0); HighCount++)
    //    {
    //        for(int WidthCount = 0; WidthCount < RoomData.GetLength(1); WidthCount++)
    //        {
    //            switch ((BlockState)RoomData[HighCount, WidthCount])
    //            {
    //                case BlockState.FLOOR:
    //                    break;
    //                case BlockState.WALL:
    //                    break;
    //                case BlockState.MONSPON:
    //                    break;
    //                case BlockState.POTAL:
    //                    break;
    //            }
    //        }
    //    }
    //}
}
