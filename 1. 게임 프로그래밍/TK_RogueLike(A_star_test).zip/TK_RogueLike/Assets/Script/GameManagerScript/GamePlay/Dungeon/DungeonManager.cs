﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DungeonManager : MonoBehaviour
{
    //public int ThisDungeon_FloorCount;
    public FloorManager[] ThisDungeon;
    public FloorManager NowFloor;
    public int nNowFloor;
    //public int NowFloor;

    //public FloorManager GetNowFloor() { return ThisDungeon[NowFloor]; }

    public void SetNowFloor()
    {
        if(NowFloor == null)
        {
            //for(int FloorCount = 0; FloorCount<ThisDungeon.Length;FloorCount++)
            //{
            //    if(ThisDungeon[FloorCount])
            //}
            nNowFloor = 0;
            NowFloor = ThisDungeon[nNowFloor];
        }
        else
        {
            if(NowFloor.Status == FloorManager.FloorStatus.IS_CREAL)
            {
                nNowFloor++;
                NowFloor = ThisDungeon[nNowFloor];
            }
        }
    }
    
    // Start is called before the first frame update
    void Start()
    {
        //ThisDungeon = new FloorManager[ThisDungeon_FloorCount];
        //NowFloor = 0;
    }

    // Update is called once per frame
    void Update()
    {
        SetNowFloor();
    }
}
