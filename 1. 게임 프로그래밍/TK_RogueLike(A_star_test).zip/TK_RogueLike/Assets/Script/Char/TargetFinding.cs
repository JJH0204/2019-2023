﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TargetFinding : MonoBehaviour
{
    public void MonSeeTargetFinding(Character ThisChar, GameObject m_gSeeTarget, Vector3 vResultDir, string sTargetTag)
    {
        int nLayer = 1 << LayerMask.NameToLayer(sTargetTag);
        Collider2D Seecollider = Physics2D.OverlapCircle(this.transform.position, ThisChar.GetSeeRadius(), nLayer);
        if (Seecollider != null)
        {
            m_gSeeTarget = Seecollider.gameObject;
        }
        else
        {
            if (m_gSeeTarget)
                if (m_gSeeTarget.tag == sTargetTag)
                    m_gSeeTarget = null;
        }

        if (m_gSeeTarget)
        {
            Vector3 vTargetPos = m_gSeeTarget.gameObject.transform.position;
            Vector3 vPlayerPos = this.transform.position;

            Vector3 vDist = vTargetPos - vPlayerPos;
            Vector3 vDir = vDist.normalized;
            vResultDir = vDir;
        }
    }
    public void MonAtkTargetFinding(Character ThisChar, GameObject m_gAtkTarget, string sTargetTag)
    {
        int nLayer = 1 << LayerMask.NameToLayer(sTargetTag);

        if (ThisChar.m_drowItem == null) return;
        Collider2D Atkcollider = Physics2D.OverlapCircle(this.transform.position, ThisChar.m_drowItem.GetComponent<Item>().m_fAtkRadius, nLayer);

        if (Atkcollider != null)
            m_gAtkTarget = Atkcollider.gameObject;
        else
        {
            if (m_gAtkTarget)
            {
                if (m_gAtkTarget.tag == sTargetTag)
                    m_gAtkTarget = null;
            }
        }
    }
}
