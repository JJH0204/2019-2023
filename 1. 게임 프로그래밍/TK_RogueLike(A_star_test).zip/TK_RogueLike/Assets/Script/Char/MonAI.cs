﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/* 몬스터 이동 행동 구현
 * 1. 시야 범위내 적(Player)가 없으면 추적하지 않고 움직인다.
 * 2. 시야 범위내 적을 발견하면 적을 추적해 움직인다.
 * 3. 시야 범위내 적을 추적해 공격가능 범위에 들어오면 움직이지 않고 공격한다.
 * 예외사항) 적으로 부터 공격 받았을 때 해당 적을 타겟으로 행동한다.
 * */
public class MonAI : MonoBehaviour
{
    Character ThisMon;
    private RandMove cRandMove;
    private TargetFinding cTargetFinding;
    private A_star cA_Star;
    public enum CharState { IDLE, MOVE, ATTACK , DEATH };
    public CharState ThisCharState;
    
    public GameObject m_gSeeTarget, m_gAtkTarget;
    
    public Vector3 vResultDir;

    public float deleyAtk;              //공격 대기 시간 () 아이템의 공격대기시간도 추가로 계산

    //public bool isAttack;

    private Rigidbody2D rigidbody2;

    public BossSkill bossSkill;


    private void Awake()
    {
        cRandMove = new RandMove();
        ThisMon = this.GetComponent<Character>();
        bossSkill = this.gameObject.GetComponent<BossSkill>();
        rigidbody2 = this.gameObject.GetComponent<Rigidbody2D>();
        //isAttack = false;
    }

    void Start()
    {

    }

    void Update()
    {
        Action();
    }

    private void FixedUpdate()
    {
        Mon_AI();
    }

    private void OnDrawGizmos()
    {
        if (ThisMon == null) return;
        Gizmos.DrawWireSphere(this.transform.position, ThisMon.GetSeeRadius());
        if (ThisMon.m_drowItem != null)
            if (ThisMon.m_drowItem.GetComponent<Item>().m_fAtkRadius > 0)
                Gizmos.DrawWireSphere(this.transform.position, ThisMon.m_drowItem.GetComponent<Item>().m_fAtkRadius);

        if (FinalNodeList.Count != 0) for (int i = 0; i < FinalNodeList.Count - 1; i++)
            Gizmos.DrawLine(new Vector2(FinalNodeList[i].x, FinalNodeList[i].y), new Vector2(FinalNodeList[i + 1].x, FinalNodeList[i + 1].y));
    }

    private void Mon_AI()
    {
        cTargetFinding.MonSeeTargetFinding(ThisMon, m_gSeeTarget, vResultDir, "Player");
        cTargetFinding.MonAtkTargetFinding(ThisMon, m_gAtkTarget, "Player");

        if (m_gSeeTarget == null)
        {
            PathFindingAllClear();
        }

        if (ThisMon.GetHP() <= 0)
        {
            ThisCharState = CharState.DEATH;
        }
        else
        {
            if (m_gAtkTarget != null)
            {
                ThisCharState = CharState.ATTACK;
            }
            else if (m_gSeeTarget != null)
            {
                if (ThisMon.Level == Character.LV.BOSS)
                    ThisCharState = CharState.ATTACK;
                else
                {
                    SetPathFindingData();
                    PathFinding();
                    ThisCharState = CharState.MOVE;
                }
            }
            else
            {
                // 이 부분을 코루틴으로 함수화 시키자
                if (cRandMove.isSetDir == false)
                    StartCoroutine(cRandMove.SetRandDir(ThisCharState, vResultDir));
                //##############################
            }
        }
    }

    private void Action()
    {
        ThisMon.SeeTrak(m_gSeeTarget);

        switch (ThisCharState)
        {
            case CharState.IDLE:  //기본 상태
                
                //행동 여부 판단
                //이동 방향 선정
                //이동 상태로 변경
                break;
            case CharState.MOVE:  //이동 상태
                //RayHit();
                //선정한 이동 방향으로 이동
                //행동 여부 판단
                //만약 이동 상태 유지할 경우
                //이동 방향 선정
                
                //ThisMon.Move(vResultDir);
                Debug.Log(vResultDir);
                //지정된 대상을 향해 이동
                //지정된 대상이 유지 된다면 
                break;
            case CharState.ATTACK://공격 상태
                MonAtk();
                
                //지정된 대상 공격
                break;
            case CharState.DEATH:   //죽음 상태
                if(bossSkill != null)
                {
                    if (bossSkill.ThrowKnifes.GetIsSkill() == true) bossSkill.ThrowKnifes.AllKnifeDelete();
                }
                    
                ThisMon.Death();
                break;
        }

        //Invoke("MonsterAI", 5);
    }
    //############################################################################################################
    

    //private void Move()
    //{
    //    this.gameObject.transform.position += vResultDir * Time.deltaTime * ThisMon.GetSpeed();
    //    Debug.Log(vResultDir);

    //}

    private void MonAtk()
    {
        if (ThisMon.GetIsAttack() || bossSkill) return;

        if (bossSkill != null)
            bossSkill.BossUsedSkill(m_gSeeTarget, deleyAtk);
        else
            StartCoroutine(ThisMon.Attack(m_gSeeTarget, m_gAtkTarget, deleyAtk));
    }

    
    

   
    //private void OnCollisionEnter2D(Collision2D collision)
    //{
    //    if(collision.gameObject.tag == "Wall")
    //    {
    //        Vector3 vTarget = collision.gameObject.transform.position;
    //        Vector3 vPos = this.transform.position;
    //        Vector3 vDist = vTarget - vPos;
    //        Vector3 vDir = vDist.normalized;

    //        Debug.Log("Monster collision vDir" + vDir);
    //    }
    //}
    //동작과 ai를 분리 
    //ray 로 이동시 충돌된 지점과 반대되는 방향으로 몬스터가 이동할 수 있도록 감지 범위 설정하고 함수 재작
    //ray hit
    //private void RayHit()
    //{
    //    //Vector3 vFront = this.transform.position += vResultDir * Time.deltaTime * ThisMon.GetSpeed();

    //    //Debug.DrawRay(vFront, vResultDir, new Color(0, 1, 0));
    //    //RaycastHit2D rayHit = Physics2D.Raycast(this.transform.position, Vector3.right, 0.1f);
    //    //if(rayHit.collider != null)
    //    //{
    //    //    if(rayHit.distance<0.5f)
    //    //    {

    //    //    }
    //    //}
    //    //Ray ray = new Ray(this.transform.position + vResultDir * Time.deltaTime * ThisMon.GetSpeed(), vResultDir);
    //    //RaycastHit2D RayHit;
    //    //if(Physics.Raycast(ray, vResultDir, 1.0f));
    //    Debug.Log("call RayHit()");
    //    int nLayer = 1 << LayerMask.NameToLayer("Wall");
    //    Vector3 NowPos = this.gameObject.transform.position;
    //    Vector3 NextMove = this.gameObject.transform.position + vResultDir * Time.deltaTime * ThisMon.GetSpeed();
    //    Debug.DrawRay(NextMove, vResultDir, new Color(0, 1, 0));
    //    RaycastHit2D RayHit = Physics2D.Raycast(NextMove, vResultDir, /*(NextMove-NowPos).magnitude,*/ nLayer);
    //    if(RayHit.collider != null)
    //    {
    //        Debug.Log("is Ray Hit");
    //        Debug.Log(RayHit.collider.gameObject.tag);
    //        if (RayHit.collider.gameObject.tag == "Wall")
    //        {
    //            Debug.Log("Hit collider is Wall"); 
    //            vResultDir = -vResultDir;
    //        }
            
                
    //    }
    //}

    //TEST#####################################################################
    public GameObject StartObject, TargetObject;
    public Vector2Int bottomLeft, topRight, startPos, targetPos;
    public List<Node> FinalNodeList;
    public bool allowDiagonal, dontCrossCorner;

    int sizeX, sizeY;
    Node[,] NodeArray;
    Node StartNode, TargetNode, CurNode;
    List<Node> OpenList, ClosedList;


    public void PathFinding()
    {
        startPos.x = (int)StartObject.transform.position.x;
        startPos.y = (int)StartObject.transform.position.y;
        targetPos.x = (int)TargetObject.transform.position.x;
        targetPos.y = (int)TargetObject.transform.position.y;
        // NodeArray의 크기 정해주고, isWall, x, y 대입
        sizeX = topRight.x - bottomLeft.x + 1;
        sizeY = topRight.y - bottomLeft.y + 1;
        NodeArray = new Node[sizeX, sizeY];

        for (int i = 0; i < sizeX; i++)
        {
            for (int j = 0; j < sizeY; j++)
            {
                bool isWall = false;
                foreach (Collider2D col in Physics2D.OverlapCircleAll(new Vector2(i + bottomLeft.x, j + bottomLeft.y), 0.4f))
                    if (col.gameObject.layer == LayerMask.NameToLayer("Wall")) isWall = true;

                NodeArray[i, j] = new Node(isWall, i + bottomLeft.x, j + bottomLeft.y);
            }
        }


        // 시작과 끝 노드, 열린리스트와 닫힌리스트, 마지막리스트 초기화
        StartNode = NodeArray[startPos.x - bottomLeft.x, startPos.y - bottomLeft.y];
        TargetNode = NodeArray[targetPos.x - bottomLeft.x, targetPos.y - bottomLeft.y];

        OpenList = new List<Node>() { StartNode };
        ClosedList = new List<Node>();
        FinalNodeList = new List<Node>();


        while (OpenList.Count > 0)
        {
            // 열린리스트 중 가장 F가 작고 F가 같다면 H가 작은 걸 현재노드로 하고 열린리스트에서 닫힌리스트로 옮기기
            CurNode = OpenList[0];
            for (int i = 1; i < OpenList.Count; i++)
                if (OpenList[i].F <= CurNode.F && OpenList[i].H < CurNode.H) CurNode = OpenList[i];

            OpenList.Remove(CurNode);
            ClosedList.Add(CurNode);


            // 마지막
            if (CurNode == TargetNode)
            {
                Node TargetCurNode = TargetNode;
                while (TargetCurNode != StartNode)
                {
                    FinalNodeList.Add(TargetCurNode);
                    TargetCurNode = TargetCurNode.ParentNode;
                }
                FinalNodeList.Add(StartNode);
                FinalNodeList.Reverse();

                for (int i = 0; i < FinalNodeList.Count; i++) print(i + "번째는 " + FinalNodeList[i].x + ", " + FinalNodeList[i].y);
                return;
            }


            // ↗↖↙↘
            if (allowDiagonal)
            {
                OpenListAdd(CurNode.x + 1, CurNode.y + 1);
                OpenListAdd(CurNode.x - 1, CurNode.y + 1);
                OpenListAdd(CurNode.x - 1, CurNode.y - 1);
                OpenListAdd(CurNode.x + 1, CurNode.y - 1);
            }

            // ↑ → ↓ ←
            OpenListAdd(CurNode.x, CurNode.y + 1);
            OpenListAdd(CurNode.x + 1, CurNode.y);
            OpenListAdd(CurNode.x, CurNode.y - 1);
            OpenListAdd(CurNode.x - 1, CurNode.y);
        }
    }

    void OpenListAdd(int checkX, int checkY)
    {
        // 상하좌우 범위를 벗어나지 않고, 벽이 아니면서, 닫힌리스트에 없다면
        if (checkX >= bottomLeft.x && checkX < topRight.x + 1 && checkY >= bottomLeft.y && checkY < topRight.y + 1 && !NodeArray[checkX - bottomLeft.x, checkY - bottomLeft.y].isWall && !ClosedList.Contains(NodeArray[checkX - bottomLeft.x, checkY - bottomLeft.y]))
        {
            // 대각선 허용시, 벽 사이로 통과 안됨
            if (allowDiagonal) if (NodeArray[CurNode.x - bottomLeft.x, checkY - bottomLeft.y].isWall && NodeArray[checkX - bottomLeft.x, CurNode.y - bottomLeft.y].isWall) return;

            // 코너를 가로질러 가지 않을시, 이동 중에 수직수평 장애물이 있으면 안됨
            if (dontCrossCorner) if (NodeArray[CurNode.x - bottomLeft.x, checkY - bottomLeft.y].isWall || NodeArray[checkX - bottomLeft.x, CurNode.y - bottomLeft.y].isWall) return;


            // 이웃노드에 넣고, 직선은 10, 대각선은 14비용
            Node NeighborNode = NodeArray[checkX - bottomLeft.x, checkY - bottomLeft.y];
            int MoveCost = CurNode.G + (CurNode.x - checkX == 0 || CurNode.y - checkY == 0 ? 10 : 14);


            // 이동비용이 이웃노드G보다 작거나 또는 열린리스트에 이웃노드가 없다면 G, H, ParentNode를 설정 후 열린리스트에 추가
            if (MoveCost < NeighborNode.G || !OpenList.Contains(NeighborNode))
            {
                NeighborNode.G = MoveCost;
                NeighborNode.H = (Mathf.Abs(NeighborNode.x - TargetNode.x) + Mathf.Abs(NeighborNode.y - TargetNode.y)) * 10;
                NeighborNode.ParentNode = CurNode;

                OpenList.Add(NeighborNode);
            }
        }
    }
    void SetPathFindingData()
    {
        StartObject = this.gameObject;
        TargetObject = m_gSeeTarget;
        PlayManager playManager = PlayManager.GetInstance();
        bottomLeft = Vector2Int.zero;
        topRight.x = playManager.DungeonManager.NowFloor.NowRoom.RoomWidth;
        topRight.y = playManager.DungeonManager.NowFloor.NowRoom.RoomHight;
    }
    void PathFindingAllClear()
    {
        FinalNodeList.Clear();
    }
    //void OnDrawGizmos()
    //{
    //    if (FinalNodeList.Count != 0) for (int i = 0; i < FinalNodeList.Count - 1; i++)
    //            Gizmos.DrawLine(new Vector2(FinalNodeList[i].x, FinalNodeList[i].y), new Vector2(FinalNodeList[i + 1].x, FinalNodeList[i + 1].y));
    //}
}
