﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandMove : MonoBehaviour
{
    public enum MoveDir { IDLE, TOP, RIGHT, BOTTOM, LEFT, TR, BR, BL, TL };
    public MoveDir ThisMoveDir;
    public bool isSetDir;

    public IEnumerator SetRandDir(MonAI.CharState ThisCharState, Vector3 vResultDir)
    {
        //Debug.Log("Coroutine_1");
        //
        //Debug.Log("Coroutine_2");
        isSetDir = true;
        int nRand = Random.Range(0, 9);
        if (nRand > 0) ThisCharState = MonAI.CharState.MOVE;
        else ThisCharState = MonAI.CharState.IDLE;
        ThisMoveDir = (MoveDir)nRand;
        SetResultDir(vResultDir);
        yield return new WaitForSeconds(5.0f);
        isSetDir = false;
        //StopAllCoroutines();
        //Debug.Log("Coroutine_3");
        //yield return new WaitForSeconds(5.0f);
    }

    public void SetResultDir(Vector3 vResultDir)
    {
        switch (ThisMoveDir)
        {
            case MoveDir.TOP:
                vResultDir = Vector3.up;
                break;
            case MoveDir.BOTTOM:
                vResultDir = Vector3.down;
                break;
            case MoveDir.LEFT:
                vResultDir = Vector3.left;
                break;
            case MoveDir.RIGHT:
                vResultDir = Vector3.right;
                break;
            case MoveDir.TL:
                vResultDir = Vector3.up + Vector3.left;
                break;
            case MoveDir.TR:
                vResultDir = Vector3.up + Vector3.right;
                break;
            case MoveDir.BL:
                vResultDir = Vector3.down + Vector3.left;
                break;
            case MoveDir.BR:
                vResultDir = Vector3.down + Vector3.right;
                break;
        }
        Debug.Log(vResultDir);
    }

}
