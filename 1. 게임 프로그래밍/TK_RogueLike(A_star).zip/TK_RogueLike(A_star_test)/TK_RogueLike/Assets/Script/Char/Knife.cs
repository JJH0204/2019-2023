﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Knife : MonoBehaviour
{
    public float m_fPower;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Rigidbody2D thisRigid = this.gameObject.GetComponent<Rigidbody2D>();
        //thisRigid.AddForce(-startForc);
        if (collision.gameObject.tag == "Player")
        {
            Character TargetChar = collision.gameObject.GetComponent<Character>();
            TargetChar.SetHP(TargetChar.GetHP() - m_fPower / TargetChar.GetShilde());
        }
        if(collision.gameObject.tag != "Monster")
            Destroy(this.gameObject);
    }
}
