﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Skill_ThrowKnife : MonoBehaviour
{
    public GameObject[] KnifePos;
    public GameObject KnifePrefap;
    public GameObject[] ProdKnife;

    public bool isSkill;
    public bool isThrow;
    public bool isSpon;
    
    private void Awake()
    {
        isSkill = false;
        isThrow = false;
        isSpon = false;

    }

    public void UseSkill(GameObject Target, float deleyAtk)
    {
        isSkill = true;
        if (isSpon == false)
        {
            SponKnife();
        }


        if (isThrow == false && isSpon != false)
        {
            StartCoroutine(ThrowKnife(Target, deleyAtk));
        }

        
    }

    private void SponKnife()
    {
        isSpon = false;
        ProdKnife = new GameObject[KnifePos.Length];
        for (int count = 0; count < KnifePos.Length; count++)
        {
            ProdKnife[count] = Instantiate(KnifePrefap);
            ProdKnife[count].transform.position = KnifePos[count].transform.position;
        }
        isSpon = true;
    }

    private IEnumerator ThrowKnife(GameObject Target, float deleyAtk)
    {
        isThrow = true;
        yield return new WaitForSeconds(deleyAtk);
        for (int count = 0; count < ProdKnife.Length; count++)
        {
            Vector3 vTarget = Target.transform.position;
            Vector3 vThisPos = ProdKnife[count].transform.position;

            //칼 돌리기
            float fWidth = vTarget.x - vThisPos.x;
            float fHeight = vTarget.y - vThisPos.y;
            float fRadian = Mathf.Atan2(fWidth, fHeight);
            float fAngle = fRadian * 180 / Mathf.PI;
            ProdKnife[count].transform.rotation = Quaternion.Euler(0, 0, -fAngle);

            //칼 날리기
            Vector3 vDist = vTarget - vThisPos;
            Vector3 vDir = vDist.normalized;
            Rigidbody2D KnifeRigid = ProdKnife[count].GetComponent<Rigidbody2D>();
            KnifeRigid.AddForce(vDir * 1000);
            
            yield return new WaitForSeconds(0.5f);
            if (count == ProdKnife.Length - 1)
                isSpon = false;
        }
        isThrow = false;
        isSkill = false;
    }
    public bool GetIsSkill()
    {
        return isSkill;
    }
    public void AllKnifeDelete()
    {
        if (ProdKnife == null) return;
        for(int count = 0; count<ProdKnife.Length; count++)
        {
            if (ProdKnife[count] == null) continue;
            Destroy(ProdKnife[count]);
        }
    }
}
