﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossSkill : MonoBehaviour
{
    public enum nowSkill { Skill_1, Skill_2, Skill_3};
    public nowSkill NowSkill;
    //스킬
    public Skill_ThrowKnife ThrowKnifes;
    public Skill_TrowBall ThrowBall;

    public bool isWarking;

    private void Awake()
    {
        ThrowKnifes = this.gameObject.GetComponent<Skill_ThrowKnife>();
        ThrowBall = this.gameObject.GetComponent<Skill_TrowBall>();
        isWarking = false;
    }
    public void BossUsedSkill(GameObject Target, float deleyAtk)
    {
        if(isWarking == false)
        {
            int num = Random.Range(0, 2);
            NowSkill = (nowSkill)num;
            isWarking = true;
        }
        
        switch(NowSkill)
        {
            case nowSkill.Skill_1:
                ThrowKnifes.UseSkill(Target, deleyAtk);
                if (ThrowKnifes.GetIsSkill() == false)
                    isWarking = false;
                break;
            case nowSkill.Skill_2:
                ThrowBall.UseSkill(deleyAtk);
                if (ThrowBall.GetIsSkill() == false)
                    isWarking = false;
                break;
            case nowSkill.Skill_3:
                break;
        }
    }
}
