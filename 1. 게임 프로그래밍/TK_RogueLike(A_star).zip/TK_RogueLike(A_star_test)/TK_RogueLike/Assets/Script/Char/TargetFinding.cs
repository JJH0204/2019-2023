﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TargetFinding : MonoBehaviour
{
    public TargetFinding() { }
    public GameObject MonSeeTargetFinding(GameObject thisGameObject, GameObject m_gSeeTarget, string sTargetTag)
    {
        int nLayer = 1 << LayerMask.NameToLayer(sTargetTag);
        Collider2D Seecollider = Physics2D.OverlapCircle(thisGameObject.transform.position, thisGameObject.GetComponent<Character>().GetSeeRadius(), nLayer);
        if (Seecollider != null)
        {
            return Seecollider.gameObject;
        }
        else
        {
            if (m_gSeeTarget)
                if (m_gSeeTarget.tag == sTargetTag)
                    return null;
        }
        return null;
    }
    public GameObject MonAtkTargetFinding(GameObject thisGameObject, GameObject m_gAtkTarget, string sTargetTag)
    {
        int nLayer = 1 << LayerMask.NameToLayer(sTargetTag);

        if (thisGameObject.GetComponent<Character>().m_drowItem == null) return null;
        Collider2D Atkcollider = Physics2D.OverlapCircle(thisGameObject.transform.position, thisGameObject.GetComponent<Character>().m_drowItem.GetComponent<Item>().m_fAtkRadius, nLayer);

        if (Atkcollider != null)
            return Atkcollider.gameObject;
        else
        {
            if (m_gAtkTarget)
            {
                if (m_gAtkTarget.tag == sTargetTag)
                    return null;
            }
        }
        return null;
    }
}
