﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Skill_TrowBall : MonoBehaviour
{
    public GameObject[] ShootPos;
    public GameObject IdlingObject;
    public GameObject ShootBulletPrefap;

    public float fIdling;

    public bool isSkill;

    private void Awake()
    {
        isSkill = false;
    }

    public void UseSkill(float deleyAtk)
    {
        StartCoroutine(StopUse(deleyAtk));
        if (isSkill == true)
        {
            for (int count = 0; count < ShootPos.Length; count++)
            {
                GameObject ShootBullet = Instantiate(ShootBulletPrefap);
                ShootBullet.transform.position = ShootPos[count].transform.position;
                bulletShoot(ShootBullet);
            }
            IdlingObject.transform.rotation = Quaternion.Euler(0, 0, fIdling);
            fIdling += 2;

        }
    }
    private void bulletShoot(GameObject Bullet)
    {
        Vector3 vThisObject = this.gameObject.transform.position;
        Vector3 vTarget = Bullet.transform.position;

        Vector3 vDist = vTarget - vThisObject;
        Vector3 vDir = vDist.normalized;

        Bullet.GetComponent<Rigidbody2D>().AddForce(vDir * 1000);
    }

    private IEnumerator StopUse(float deleyAtk)
    {
        if (isSkill == true)
        {
            yield return new WaitForSeconds(deleyAtk);
            isSkill = false;
        }
        else
        {
            yield return new WaitForSeconds(deleyAtk);
            isSkill = true;
        }
    }
    public bool GetIsSkill()
    {
        return isSkill;
    }
}
