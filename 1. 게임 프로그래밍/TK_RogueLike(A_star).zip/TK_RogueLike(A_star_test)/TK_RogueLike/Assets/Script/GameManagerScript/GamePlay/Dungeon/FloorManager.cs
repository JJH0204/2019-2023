﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FloorManager : MonoBehaviour
{
    //public string FloorName;
    //public int ThisFloor_RoomCount;
    public RoomManager[] ThisFloor;
    public RoomManager NowRoom;
    //public int NowRoom;
    public GameObject Potalprefap;
    //public RoomManager GetNowRoom() { return ThisFloor[NowRoom]; }
    public enum FloorStatus { IS_UNCREAL, IS_CREAL };
    public FloorStatus Status;
    // Start is called before the first frame update
    private void SetFloor()
    {
        if (NowRoom == null)
        {
            for(int RoomCount = 0; RoomCount<ThisFloor.Length;RoomCount++)
            {
                if(ThisFloor[RoomCount].Kind == RoomManager.RoomKind.START)
                {
                    NowRoom = ThisFloor[RoomCount];
                    Status = FloorStatus.IS_UNCREAL;
                }
            }

            if (NowRoom == null)
            {
                Debug.Log("Start Room is NULL"); //현재 사용하지 않는 층의 스타팅 점을 찾지 못한다고 에러 로그를 띄움(에러)//스타팅 룸을 정해주면서 해결
                Application.Quit();
            }
        }
    }

    private void FloorClearUpdate()
    {
        if (NowRoom == null) return;

        if((NowRoom.Kind == RoomManager.RoomKind.BOSS)&&(NowRoom.isClear==true))
        {
            Status = FloorStatus.IS_CREAL;
        }
    }

    void Start()
    {
        //ThisFloor = new RoomManager[ThisFloor_RoomCount];
        //NowRoom = 0;
    }

    // Update is called once per frame
    void Update()
    {
        SetFloor();
        FloorClearUpdate();
    }
}
