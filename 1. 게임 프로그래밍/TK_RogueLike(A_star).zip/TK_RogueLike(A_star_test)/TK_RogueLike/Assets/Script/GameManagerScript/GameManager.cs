﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    //게임 진행 관리
    static GameManager instance;

    public PlayManager PlayManager;
    public CarmeraManager CarmeraManager;

    //public SponManager MonSpon; // Room Managaer로 기능 양도 예정
    
    public bool isGameOver;
    
    public static GameManager GetInstance() { return instance; }

    
    void Start()
    {
        instance = this;
    }

 
    void Update()
    {
        //MonSpon.SponMonster();
        //if (!MonSpon.StillAliveMon())
        //{
        //    ItemManager.BoxRander();
        //}
        //if(isBoxRander)
        //{
        //    Debug.Log("GameOver");
        //}
    }
}
