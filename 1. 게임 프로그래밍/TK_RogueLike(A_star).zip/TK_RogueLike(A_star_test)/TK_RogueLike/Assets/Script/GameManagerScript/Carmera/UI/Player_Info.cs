﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player_Info : MonoBehaviour
{
    public PlayerManager PlayerManager;
    public GUI_StatusBar HPBar;

    void SetPlayerInfo(Character Player){ HPBar.SetStatusBar(Player.fHP, Player.Max_fHP); }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (PlayerManager.Player)
        {
            Character cPlayer = PlayerManager.Player.GetComponent<Character>();
            SetPlayerInfo(cPlayer);
        }
    }
}
