﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Item : MonoBehaviour
{
    public int Score = 0;
    
    //private void OnCollisionEnter2D(Collision2D collision)
    //{
    //    if (collision.gameObject.tag == "Player")
    //    {
    //        Move Player = collision.ge;
    //        Player.Score += this.Score;
    //        Destroy(gameObject);
    //    }
    //}
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            Move Player = collision.GetComponent<Move>();
            Player.Score += this.Score;
            Destroy(gameObject);
        }
    }
}
