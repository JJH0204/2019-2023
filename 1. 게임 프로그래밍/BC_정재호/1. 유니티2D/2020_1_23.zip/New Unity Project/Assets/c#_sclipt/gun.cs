﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gun : MonoBehaviour
{
    public GameObject obj;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Mouse0))
        {
            GameObject intanceobj = Instantiate(obj);
            intanceobj.transform.position = this.transform.position;
            Rigidbody2D rigidbody2D = intanceobj.GetComponent<Rigidbody2D>();
            rigidbody2D.AddForce(Vector2.right * 200); //(방향 * 가해지는 힘)
            
        }
    }
}
