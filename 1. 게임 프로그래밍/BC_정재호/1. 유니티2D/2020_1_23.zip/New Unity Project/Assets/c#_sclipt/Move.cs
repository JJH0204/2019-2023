﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour
{
    public float JumpForce = 150.0f;
    public bool isJump = false;
    public bool isLadder = false;
    public int Score = 0;
    Rigidbody2D Rigidbody;
    // Start is called before the first frame update
    void Start()
    {
        Rigidbody = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {

        //키를 입력하여 캐릭터를 이동
        if (Input.GetKey(KeyCode.D))
            transform.position += Vector3.right * Time.deltaTime;
        else if (Input.GetKey(KeyCode.A))
            transform.position += Vector3.left * Time.deltaTime;
        if(isLadder == true)
        {
            if (Input.GetKey(KeyCode.W))
                transform.position += Vector3.up * Time.deltaTime;
            else if (Input.GetKey(KeyCode.S))
                transform.position += Vector3.down * Time.deltaTime;
        }
        
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (isJump == false) //공중에서는 점프가 되지 않도록 하기 위해 조건을 걸음
            {
                if(isLadder == true)
                {
                    Rigidbody.gravityScale = 1;
                }
                Rigidbody2D rigidbody = GetComponent<Rigidbody2D>(); //강체
                rigidbody.AddForce(Vector3.up * JumpForce); //방향으로 힘을 가함
                isJump = true;
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        isJump = false;
       // Debug.Log("OnCollisionEnter2D: " + collision.gameObject.name);
        
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        
       // Debug.Log("OnCollisionExit2D: " + collision.gameObject.name);
    }

    //하단에 있는 구조물의 정보를 출력
    private void OnCollisionStay2D(Collision2D collision)
    {
       // Debug.Log("OnCollisionStay2D: " + collision.gameObject.name);
       
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        //if (collision.gameObject.name == "Ladder")
        //GetComponent<CircleCollider2D>().isTrigger = true;
        if(collision.gameObject.tag == "Ladder")
        {
            if(isJump==true) Rigidbody.velocity = Vector2.zero;
            isLadder = true;
            Rigidbody.gravityScale = 0;
            Debug.Log("OnTriggerEnter2D: " + collision.gameObject.name);
        }
        
    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        isLadder = true;
        Rigidbody.gravityScale = 0;
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        isLadder = false;
       // GetComponent<CircleCollider2D>().isTrigger = false;
        Rigidbody.gravityScale = 1;
        Debug.Log("OnTriggerExit2D: " + collision.gameObject.name);
    }

}
/* rigidbody(강체) : 중력의 영향을 받는 대상
 * Collider (충돌) : 충돌처리함
 * Constraints (
 * Collision(충돌, 충돌 대상)
 **/

    /*에러
     * 1. 사다리를 점프를 이용해 입장하게 되면 중력에 영향을 받게되어 사다리를 내려오게 된다.
     *  - 리지드 바디의 벨로시티 값을 벡터 제로로 만들어 가한 힘을 0으로 만들어 주었다.
     * 
     * 
     * */