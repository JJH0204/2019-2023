﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bullet : MonoBehaviour
{
    Vector3 vStartPos;
    public float Range;
    // Start is called before the first frame update
    void Start()
    {
        vStartPos = transform.position; //총알이 생성된 위치를 저장
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 vCurPos = transform.position; //현재 총알의 위치를 저장
        Vector3 vDist = vCurPos - vStartPos; //현재 위치에서 시작 위치를 빼 거리와 방향을 구함
        float fDist = vDist.magnitude;  //magnitude 함수를 사용해 방향값을 제거 한다. 이동 거리만 활용

        if (fDist > Range) //사거리 값과 비교해 사거리를 벗어나면 삭제
            Destroy(this.gameObject);
    }
    
}
