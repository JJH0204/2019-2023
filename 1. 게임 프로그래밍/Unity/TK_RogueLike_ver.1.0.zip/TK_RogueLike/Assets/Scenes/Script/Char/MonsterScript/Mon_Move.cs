﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mon_Move : MonoBehaviour
{
    public Character player;
    public float Speed;
    public Vector3 vDirResult;
    public GameObject SeeTarget;

    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(this.transform.position, this.gameObject.GetComponent<Character>().fSeeRadius);
    }
    private void FixedUpdate()
    {
        int nLayer = 1 << LayerMask.NameToLayer("Player");
        Character thisChar = this.gameObject.GetComponent<Character>();

        Collider2D Seecollider = Physics2D.OverlapCircle(this.transform.position, thisChar.fSeeRadius, nLayer);

        if (Seecollider != null)
        {
            SeeTarget = Seecollider.gameObject;
            Debug.Log("SeeTarget : " + SeeTarget.name);
        }
        else
        {
            if (SeeTarget)
            {
                if (SeeTarget.tag == "Player")
                {
                    SeeTarget = null;
                    Debug.Log("SeeFixedUpdate: null");
                }
                else
                    Debug.Log("SeeTarget:" + SeeTarget);
            }
            Debug.Log("SeeTarget is null");
        }

        if (SeeTarget)
        {
            Vector3 vTargetPos = SeeTarget.gameObject.transform.position;
            Vector3 vPlayerPos = this.transform.position;

            Vector3 vDist = vTargetPos - vPlayerPos;
            Vector3 vDir = vDist.normalized;
            vDirResult = vDir;
        }
        else
            vDirResult = Vector3.zero;
    }
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        player = this.gameObject.GetComponent<Character>();
        Speed = player.fSpeed;

        gameObject.transform.position += vDirResult * Time.deltaTime * Speed;
    }
}