﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Akt : MonoBehaviour
{
    //플레이어가 공격키(k)를 누르면 가장 가까운 적을 타겟으로 공격을 함
    //1. 플레이 주위에 공격 범위(range)에 해당하는 가상의 원을 그린다. //공격 범위는 플레이어 캐릭터에 저장된 정보
    //2. 해당 원안에 존재하는 게임오브젝트의 테그를 확인해 몬스터면 위치값 저장
    //3. 저장한 위치값과 플레이어 캐릭터의 위치값을 계산해 공격 방향을 설정
    //4. 만약 다수의 몬스터가 원안에 있는 경우 동적으로 객체를 받아와 대상을 순차적으로 거리를 비교하며 계산
    //5. 4의 과정으로 도출된 가장 가까운 적을 공격
    // Start is called before the first frame update
    public GameObject AtkTarget;
    

    //private void OnDrawGizmos()
    //{
    //    Character thisChar = this.gameObject.GetComponent<Character>();
    //    Gizmos.DrawWireSphere(this.transform.position, thisChar.fAtkRadius);
    //}
    //private void FixedUpdate()
    //{
    //    int nLayer = 1 << LayerMask.NameToLayer("Monster");
    //    Character thisChar = this.gameObject.GetComponent<Character>();
        
    //    Collider2D Atkcollider = Physics2D.OverlapCircle(this.transform.position, thisChar.fAtkRadius, nLayer);

    //    if (Atkcollider != null)
    //    {
    //        AtkTarget = Atkcollider.gameObject;
    //        Debug.Log("AtkTarget : " + AtkTarget.name);
    //    }
    //    else
    //    {
    //        if (AtkTarget)
    //        {
    //            if (AtkTarget.tag == "Monster")
    //            {
    //                AtkTarget = null;
    //                Debug.Log("FixedUpdate: null");
    //            }
    //            else
    //                Debug.Log("objTarget:" + AtkTarget);
    //        }
    //        Debug.Log("objTarget is null");
    //    }
        
    //    //CircleCollider2D circle = this.GetComponent<CircleCollider2D>(); //독수리 코드에서 충동처리를 위해 생성한 원 콜라이더 플레이어의 경우 필요 없음
    //    //collider = Physics2D.OverlapCircle(this.transform.position, circle.radius, nLayer);
    //}

    void ShootGun(Vector3 vDir)
    {

    }


    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Player_MOV MoveData = this.gameObject.GetComponent<Player_MOV>();
        if(Input.GetKeyDown(KeyCode.K))
        {
            //GameObject AtkTargetMon = null;
            //GameObject Player = this.gameObject;
            //if (AtkTarget)
            //    AtkTargetMon = AtkTarget;
            //else if (MoveData.SeeTarget)
            //    AtkTargetMon = MoveData.SeeTarget;

            //float PlayerPower = Player.GetComponent<Character>().fPower;
            //float TargetHP = AtkTargetMon.GetComponent<Character>().fHP;

            //TargetHP -= PlayerPower;
            Character Playerchar = this.gameObject.GetComponent<Character>();
            Player_MOV PlayerMoveData = this.gameObject.GetComponent<Player_MOV>();
            if(PlayerMoveData.SeeTarget == null)
                Playerchar.m_cGun.shoot(PlayerMoveData.vStandDir);
            else
                Playerchar.m_cGun.shoot(PlayerMoveData.SeeTarget);
        }
    }
}
