﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character : MonoBehaviour
{
    public float fHP;
    public float fShilde;
    public float fPower;
    public float fSpeed;
    public float fAtkRadius;
    public float fSeeRadius;
    public string UseItem;
    //플레이어 전용\\
    //public Player_Akt Atkplayer;
    //public Player_MOV Movplayer;
    //public Player_Warpon Warponplayer;
    public GunScript m_cGun;

    //몬스터 전용
    public Vector3 vDist_Player;

    public Character(float _hp, float _Shilde, float _power, float _speed, float _Atkradius, float _Seeradius)
    {
        fHP = _hp;
        fShilde = _Shilde;
        fPower = _power;
        fSpeed = _speed;
        fAtkRadius = _Atkradius;
        fSeeRadius = _Seeradius;
    }

    //void SwapWarpon()
    //{
    //    Destroy(UseWarpon);
    //    GameObject Temp = UseWarpon;
    //    UseWarpon = SubWarpon;
    //    SubWarpon = UseWarpon;
    //}

    //void DrowWarpon()
    //{
    //    ShowWarpon = Instantiate(UseWarpon);
    //    ShowWarpon.transform.position = this.transform.position + this.gameObject.GetComponent<Player_MOV>().vDirResult;
    //}
   
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(fHP<=0)
        {
            Destroy(this.gameObject);
        }
    }
}
