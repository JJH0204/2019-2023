﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    //게임 진행 관리
    public GameObject m_gCreatObj;
    public int m_nCreatCount;

    public List<GameObject> m_lCreatPos;
    public List<GameObject> m_lMonsters;

    public GameObject Player;


    void SponMonster()
    {
        for(int count = 0; count < m_nCreatCount; count++)
        {
            
            m_lMonsters[count] = Instantiate(m_gCreatObj);
            m_lMonsters[count].transform.position = m_lCreatPos[count].transform.position;
        }
    }
    //void DistCalc()
    //{
    //    for(int count = 0; count < m_nCreatCount; count++)
    //    {
    //        Character Temp = m_lMonsters[count].GetComponent<Character>();
    //        Vector3 vMonster = m_lMonsters[count].transform.position;
    //        Vector3 vPlayer = Player.transform.position;

    //        Temp.vDist_Player = vMonster - vPlayer;

    //    }
    //}
    // Start is called before the first frame update
    void Start()
    {
        SponMonster();
    }

    // Update is called once per frame
    void Update()
    {
        //DistCalc();
    }
}
