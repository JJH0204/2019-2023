﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : Character
{
    public Warpon m_UseItem;
    public Warpon m_SubItem;
    public GameObject m_drowpos;
    public GameObject m_drowItem;
    public Vector3 vStandDir;

    public Player() { }
    public Player(float _hp, float _Shilde, float _power, float _speed, float _Seeradius, float _Atkradius)
    {
        base.fHP = _hp;
        base.fShilde = _Shilde;
        base.fPower = _power;
        base.fSpeed = _speed;
        base.fSeeRadius = _Seeradius;
        base.fAtkRadius = _Atkradius;
    }

    //시선처리&공격방향(몬스터방향으로 공격하기 위한 함수 묶음)
    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(this.transform.position, base.fSeeRadius);
    }
    private void FixedUpdate()
    {
        int nLayer = 1 << LayerMask.NameToLayer("Monster");
        Character thisChar = this.gameObject.GetComponent<Character>();

        Collider2D[] Seecollider = Physics2D.OverlapCircleAll(this.transform.position, base.fSeeRadius, nLayer);

        if (Seecollider.Length > 0)
        {
            int TargetNon = 0;
            Vector3 vLeastDist = Vector3.zero;
            for (int Seecount = TargetNon; Seecount < Seecollider.Length; Seecount++)
            {
                GameObject TempSee = Seecollider[Seecount].gameObject;
                if (TempSee.tag == "Monster")
                {
                    Vector3 vTargetPos = TempSee.gameObject.transform.position;
                    Vector3 vPlayerPos = this.transform.position;

                    Vector3 vDist = vTargetPos - vPlayerPos;
                    if (vLeastDist == Vector3.zero)
                    {
                        vLeastDist = vDist;
                        TargetNon = Seecount;
                    }
                    else if (vLeastDist.magnitude > vDist.magnitude)
                    {
                        vLeastDist = vDist;
                        TargetNon = Seecount;
                    }
                }
            }

            base.m_gSeeTarget = Seecollider[TargetNon].gameObject;
           // Debug.Log("SeeTarget : " + base.m_gSeeTarget.name);
        }
        else
        {
            if (base.m_gSeeTarget)
            {
                if (base.m_gSeeTarget.tag == "Monster")
                {
                    base.m_gSeeTarget = null;
                   // Debug.Log("SeeFixedUpdate: null");
                }
                else
                    Debug.Log("SeeTarget:" + base.m_gSeeTarget);
            }
           // Debug.Log("SeeTarget is null");
        }
    }
    //현재 사용중인 무기 출력
    void DrowItme()
    {
        if ((m_UseItem != null)&&(m_drowItem==null))
            m_drowItem = Instantiate(m_UseItem.gameObject);

        m_drowItem.transform.position = m_drowpos.transform.position;
    }

    //무기 변경 함수
    void ChangItem()
    {
        Destroy(m_drowItem);
        Warpon tempwarpon;
        if (m_UseItem == null) tempwarpon = null;
        else tempwarpon = m_UseItem;

        if (m_SubItem == null) m_UseItem = null;
        else m_UseItem = m_SubItem;

        if (tempwarpon == null) m_SubItem = null;
        else m_SubItem = tempwarpon;
    }

    //공격 조작
    void Attack()
    {
        if (Input.GetKeyDown(KeyCode.K))
        {
            if(m_drowItem.GetComponent<Warpon>().m_sItemName == "Gun")
            {
                if (base.m_gSeeTarget == null)
                    m_drowItem.GetComponent<Warpon>().shoot(vStandDir);
                else
                    m_drowItem.GetComponent<Warpon>().shoot(base.m_gSeeTarget);
            }
            
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        m_drowItem = null;
    }

    // Update is called once per frame
    void Update()
    {
        DrowItme();
        {
            if (Input.GetKey(KeyCode.W))
            {
                gameObject.transform.position += Vector3.up * Time.deltaTime * base.fSpeed;
                vStandDir = Vector3.up;
            }
            if (Input.GetKey(KeyCode.A))
            {
                gameObject.transform.position += Vector3.left * Time.deltaTime * base.fSpeed;
                vStandDir = Vector3.left;
            }
            if (Input.GetKey(KeyCode.D))
            {
                gameObject.transform.position += Vector3.right * Time.deltaTime * base.fSpeed;
                vStandDir = Vector3.right;
            }
            if (Input.GetKey(KeyCode.S))
            {
                gameObject.transform.position += Vector3.down * Time.deltaTime * base.fSpeed;
                vStandDir = Vector3.down;
            }
        }//이동 조작 함수

        if (Input.GetKeyDown(KeyCode.J)) //아이템 변경
            ChangItem();
        Attack();
        base.Death();
    }
}
