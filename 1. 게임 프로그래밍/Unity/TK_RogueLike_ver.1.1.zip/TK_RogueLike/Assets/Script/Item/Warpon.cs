﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Warpon : Item
{
 
    public GameObject m_gbullet;
    public GameObject ShootPos;


    //1. 총알을 생성한다.
    //2. 총알을 캐릭터 시선 방향으로 힘을 줘 이동하게 한다.
    //3. 일정 거리 이상 이동 했을 때 or 일정 시간동안 이동하면 총알을 삭제
    //4. 총알이 벽에 부딫히면 삭제
    //5. 총알이 몬스터에 부딫히면 대상에게 데미지 부여
    public void shoot(GameObject Target)
    {
        Vector3 vThisPos = ShootPos.transform.position;
        Vector3 vTargetPos = Target.transform.position;
        Vector3 vDist = vTargetPos - vThisPos;
        Vector3 vDirResult = vDist.normalized;
        GameObject ShootBullet = Instantiate(m_gbullet);
        ShootBullet.transform.position = ShootPos.transform.position;
        //Debug.Log("ShootBullet.Position : " + ShootBullet.transform.position);
        //Debug.Log("ShootPos : " + ShootPos.transform.position);
        Rigidbody2D RigidBullet = ShootBullet.GetComponent<Rigidbody2D>();

        
        RigidBullet.AddForce(ShootBullet.GetComponent<Bullet>().startForc = vDirResult * 300);
    }
    public void shoot(Vector3 Target)
    {
        GameObject ShootBullet = Instantiate(m_gbullet);
        ShootBullet.transform.position = ShootPos.transform.position;
        Rigidbody2D RigidBullet = ShootBullet.GetComponent<Rigidbody2D>();

        ShootBullet.GetComponent<Bullet>().startForc = Target * 300;
        RigidBullet.AddForce(Target * 300);
    }
}
